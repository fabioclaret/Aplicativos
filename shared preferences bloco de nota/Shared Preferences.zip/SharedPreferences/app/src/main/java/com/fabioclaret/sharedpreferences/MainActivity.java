package com.fabioclaret.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    private AnotacaoPreferencias preferencias;
    private EditText editAnotacao;
    FloatingActionButton fbSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fbSalvar     = findViewById(R.id.floatingSalvar);
        editAnotacao = findViewById(R.id.editAnotacao);

        preferencias = new AnotacaoPreferencias(getApplicationContext());

        fbSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textoRecuperacao = editAnotacao.getText().toString();

                if( textoRecuperacao.equals("") ){
                    Toast.makeText(MainActivity.this, "Preencha o campo anotações!", Toast.LENGTH_SHORT).show();
                }else{
                    preferencias.salvarAnotacao(textoRecuperacao);
                    Toast.makeText(MainActivity.this, "Anotação salva com sucesso!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Recuperar Anotacao
        String anotacao = preferencias.recuperarAnotacao();

        if ( !anotacao.equals("") ){
            editAnotacao.setText(anotacao);
        }
    }
}